# Luofeixiang's Life Record

## Record Books

> [Journal](docs/R02/)  
> [Five-year Plans White Paper](docs/R00/)  
> [Stocks Investment Tracker Report](docs/R01/)  
