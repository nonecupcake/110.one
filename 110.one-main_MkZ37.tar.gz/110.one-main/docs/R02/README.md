# LuoFeixiang's Journal

—— Time will punish everyone who does not love to document life.
